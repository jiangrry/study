"""
    poll
"""
from socket import *
from select import  epoll, EPOLLIN, EPOLLERR

# 创建套接字　--> 作为关注的IO
s = socket()
s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
s.bind(('0.0.0.0', 8888))
s.listen(10)
s.setblocking(False)
# 1. 创建　poll 对象
ep = epoll()

# 建立查找字典, 通过io的fileno 找到io对象
# 始终和register 的　io　保持一致
fdmap = {s.fileno(): s}

# 2. 关注事件
ep.register(s, EPOLLIN)

# 3. 循环检测　io 事件发生
while True:
    events = ep.poll()  # 把　io 事件　条交给操作系统帮助我们监控
    print(events)  # [(文件描述符号, 就绪事件类型),(),()]　－－> [(3, 1)]
    # 循环遍历返回列表, 查看哪个io就绪, 进行处理
    for fd, event in events:
        # 区分哪个io就绪
        if fd == s.fileno():
            # 通过字典找到对象　处理链接
            c, addr = fdmap[fd].accept()
            print("Content from: ", addr)
            c.setblocking(False)
            ep.register(c, EPOLLIN | EPOLLERR)
            fdmap[c.fileno()] = c  # 维护字典
        # 通过就绪的事件类型　按位与　POLLIN　如果是真的话，那么就表示他就绪了
        # 如果是假的话，我们POLLIN没有就绪,就不用去执行了
        elif event & EPOLLIN:
            data = fdmap[fd].recv(1024).decode()
            if not data:
                ep.unregister(fd)# 取消对文件描述符的关注
                fdmap[fd].close()
                del fdmap[fd]
                continue
            print(data)
            fdmap[fd].send(b"Ok")
