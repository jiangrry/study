"""
    基于　select 的　socket 多路复用
    思路：
        1. 将关注的 IO 放入对应的监控类别列表
        2. 通过 select 函数进行监控
        3. 遍历 select 返回值列表，确定就绪 IO 事件
        4. 处理发生的 IO 事件
"""
from socket import *
from select import select

# 1. 定义全局变量和套接字对象
HOST = '0.0.0.0'
PORT = 8888
ADDR = (HOST, PORT)

# 创建套接字对象  --> 作为关注的IO　事件
s = socket()
s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
s.bind(ADDR)
s.listen(5)

# 设置非阻塞
s.setblocking(False)

# 2. 关注　IO 事件
rlist = [s]  # 关注　读事件
wlist = []
xlist = []
while True:
    # 循环监控IO事件发生
    # 3. select
    rs, ws, xs = select(rlist, wlist, xlist)  # select 多路复用方法　关注事件
    for r in rs:  # r --> s / c
        if r is s:  # r --> s
            # 4. 处理客户端连接
            c, addr = r.accept()
            print("Content from", addr)
            c.setblocking(False)
            rlist.append(c)
        else:
            data = r.recv(1024).decode()
            if not data:
                rlist.remove(r)  # 移除套接字　关闭
                r.close()
                continue
            print(data)
            # r.send(b"OK")
            wlist.append(r)

    for w in ws:
        w.send(b"OK")
        wlist.remove(w) # 发完消息移除
