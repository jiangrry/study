"""
    tcp 套接字客户端流程
"""

from socket import *

# 1. 创建 tcp 套接字
#   使用默认参数, --> tcp 套接字
sockfd = socket()

# 2. 连接服务器
server_addr = ("127.0.0.1", 8888)  # 服务器地址
sockfd.connect(server_addr)

# 3. 消息收发
while True:
    msg = input("msg>>>")
    if not msg:
        break
    sockfd.send(msg.encode())
    # if msg == '#':
    #     break
    data = sockfd.recv(1024)
    print("Server data: ", data.decode())

# 4. 关闭套接字
sockfd.close()
